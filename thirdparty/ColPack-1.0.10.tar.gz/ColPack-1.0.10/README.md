[![Build Status](https://travis-ci.org/CSCsw/ColPack.svg?branch=master)](https://travis-ci.org/CSCsw/ColPack)

ColPack's Doxygen documentation is available here:
http://cscapes.cs.purdue.edu/coloringpage/software.htm

ColPack's project home page:
http://cscapes.cs.purdue.edu/coloringpage/

Ubuntu Build Instructions
=========================
In the `ColPack` directory run the following:

    autoreconf -vif
    ./configure --prefix=/path/to/install/
    make -j 4   #Where "4" is the number of cores on your machine
    make install
