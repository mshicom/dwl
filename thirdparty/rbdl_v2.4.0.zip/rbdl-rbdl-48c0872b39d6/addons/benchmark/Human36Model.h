#ifndef _HUMAN36MODEL_H
#define _HUMAN36MODEL_H

namespace RigidBodyDynamics {
	class Model;
}

void generate_human36model (RigidBodyDynamics::Model *model);

/* _HUMAN36MODEL_H */
#endif
