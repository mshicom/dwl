We compare the functionality of pyadolc and pycppad.
To run the test, you'll need to install pycppad.
You can find it by googling or directly search for it on github.com


